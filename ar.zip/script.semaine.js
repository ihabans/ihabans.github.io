
var selectForm = document.forms[index];
var selectFormElement = document.forms[index].elements[index];


function add(){
   alert("hello")
   console.log(Questionnaire.elements.nom.value);
    console.log(Questionnaire.elements.prenom.value);
}


if(isset())